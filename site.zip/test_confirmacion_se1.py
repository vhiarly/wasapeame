"""
Crea dos citas de prueba para SE1 (presencial + online)
y verifica la integración con Google Calendar.
"""
import os, sys
from datetime import datetime, date, time as dtime
from dotenv import load_dotenv

load_dotenv()
sys.path.insert(0, os.path.dirname(__file__))

from db import init_pool
from negocio_router import obtener_negocio
from flujo_citas import _procesar_confirmacion
from twilio.rest import Client

init_pool()

TWILIO_NUMBER = os.getenv("TWILIO_WHATSAPP_NUMBER")
client_twilio = Client(os.getenv("TWILIO_ACCOUNT_SID"), os.getenv("TWILIO_AUTH_TOKEN"))

def twilio_send(to, body, media_url=None):
    kwargs = dict(body=body, from_=TWILIO_NUMBER, to=to)
    if media_url:
        kwargs["media_url"] = [media_url]
    try:
        client_twilio.messages.create(**kwargs)
        print(f"  ✓ Mensaje enviado a {to}")
    except Exception as e:
        print(f"  ✗ Error enviando a {to}: {e}")

negocio = obtener_negocio("SE1")
NUMERO_CLIENTE = "whatsapp:+18298789906"

# ── Cita 1: Presencial ────────────────────────────────────────────────────────
print("\n📍 Creando cita PRESENCIAL...")
estado_presencial = {
    "codigo":         "SE1",
    "dia":            "2026-06-09",
    "nombre_dia":     "Lunes",
    "hora":           "10:00",
    "tipo":           "presencial",
    "lugar":          "Nocciola (Bella Vista)",
    "servicio_clave": "asesoria_presencial",
    "cliente_nombre": "Vhiarly",
    "cliente_email":  "vhiarly@gmail.com",
}
servicio_presencial = negocio["servicios"]["asesoria_presencial"]
_procesar_confirmacion("SE1", NUMERO_CLIENTE, estado_presencial, servicio_presencial, negocio, twilio_send)
print("  ✓ Cita presencial creada")

# ── Cita 2: Online ────────────────────────────────────────────────────────────
print("\n💻 Creando cita ONLINE...")
estado_online = {
    "codigo":         "SE1",
    "dia":            "2026-06-10",
    "nombre_dia":     "Martes",
    "hora":           "14:00",
    "tipo":           "online",
    "lugar":          None,
    "servicio_clave": "asesoria_online",
    "cliente_nombre": "Vhiarly",
    "cliente_email":  "vhiarly@gmail.com",
}
servicio_online = negocio["servicios"]["asesoria_online"]
_procesar_confirmacion("SE1", NUMERO_CLIENTE, estado_online, servicio_online, negocio, twilio_send)
print("  ✓ Cita online creada")

print("\n✅ Listo. Revisa el WhatsApp de SE1 y Google Calendar.")
