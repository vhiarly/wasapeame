import os
from dotenv import load_dotenv
import psycopg2
from psycopg2.extras import Json

load_dotenv()

conn = psycopg2.connect(os.getenv("DATABASE_URL"))
cur = conn.cursor()

# Agregar columna test_mode si no existe
cur.execute("""
    ALTER TABLE negocios
    ADD COLUMN IF NOT EXISTS test_mode BOOLEAN NOT NULL DEFAULT FALSE
""")

# Quitar constraint UNIQUE de numero_negocio para permitir negocios test
cur.execute("""
    ALTER TABLE negocios
    DROP CONSTRAINT IF EXISTS negocios_numero_negocio_key
""")

# Copiar configuración de SE1
cur.execute("SELECT * FROM negocios WHERE codigo = 'SE1'")
cols = [d[0] for d in cur.description]
se1  = dict(zip(cols, cur.fetchone()))

cur.execute("""
    INSERT INTO negocios (
        codigo, nombre, tipo, modo, numero_negocio, pin, activo,
        requiere_comprobante, instrucciones_pago, lugares_reunion,
        descripcion, costo_online, costo_presencial, test_mode
    ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    ON CONFLICT (codigo) DO UPDATE SET
        nombre               = EXCLUDED.nombre,
        requiere_comprobante = EXCLUDED.requiere_comprobante,
        instrucciones_pago   = EXCLUDED.instrucciones_pago,
        lugares_reunion      = EXCLUDED.lugares_reunion,
        costo_online         = EXCLUDED.costo_online,
        costo_presencial     = EXCLUDED.costo_presencial,
        test_mode            = EXCLUDED.test_mode
""", (
    "SE2",
    se1["nombre"] + " (TEST)",
    se1["tipo"],
    se1["modo"],
    se1["numero_negocio"],     # mismo número que SE1
    "0000",
    True,
    True,                      # requiere_comprobante activo para probar el flujo
    se1["instrucciones_pago"],
    Json(se1["lugares_reunion"]) if se1.get("lugares_reunion") else None,
    se1.get("descripcion"),
    se1.get("costo_online"),
    se1.get("costo_presencial"),
    True,                      # test_mode = salta validación IA
))

# Copiar servicios de SE1
cur.execute("SELECT clave, nombre, duracion_minutos, precio, activo FROM servicios WHERE codigo = 'SE1'")
for row in cur.fetchall():
    cur.execute("""
        INSERT INTO servicios (codigo, clave, nombre, duracion_minutos, precio, activo)
        VALUES ('SE2', %s, %s, %s, %s, %s)
        ON CONFLICT (codigo, clave) DO NOTHING
    """, row)

# Copiar horarios de SE1
cur.execute("SELECT dia, trabaja, inicio, fin FROM horarios WHERE codigo = 'SE1'")
for row in cur.fetchall():
    cur.execute("""
        INSERT INTO horarios (codigo, dia, trabaja, inicio, fin)
        VALUES ('SE2', %s, %s, %s, %s)
        ON CONFLICT (codigo, dia) DO NOTHING
    """, row)

# Copiar tokens de Google Calendar de SE1
cur.execute("""
    UPDATE negocios
    SET google_access_token  = se1.google_access_token,
        google_refresh_token = se1.google_refresh_token,
        google_token_expires = se1.google_token_expires
    FROM (SELECT google_access_token, google_refresh_token, google_token_expires
          FROM negocios WHERE codigo = 'SE1') AS se1
    WHERE negocios.codigo = 'SE2'
""")

conn.commit()
cur.close()
conn.close()
print("✅ Negocio SE2 (test) creado. Código de acceso: SE2 | PIN: 0000")
