import os
from dotenv import load_dotenv
import psycopg2
from psycopg2.extras import Json

load_dotenv()

lugares = [
    {"nombre": "Flor de café (Bella Vista)", "maps": "https://maps.app.goo.gl/3VZ3KUZM93cu5QBs7"},
    {"nombre": "Juan Valdéz (Bella Vista)",  "maps": "https://maps.app.goo.gl/XcHaWHa1m1J57cah8"},
    {"nombre": "Nocciola (Bella Vista)",      "maps": "https://maps.app.goo.gl/C83nnC2hrCmYBcgu5"},
    {"nombre": "Aroma de fuego (Naco)",       "maps": "https://maps.app.goo.gl/TkoHWDHKBhKfTy7B6"},
    {"nombre": "Flor de café (Naco)",         "maps": "https://maps.app.goo.gl/davUxb3K9aDpxQTBA"},
    {"nombre": "Nocciola (Naco)",             "maps": "https://maps.app.goo.gl/gNErhXdLXxHcEbzD6"},
    {"nombre": "Casa Barista (Piantini)",     "maps": "https://maps.app.goo.gl/6mAbQPKXHeaNFZyJA"},
    {"nombre": "Granier (Piantini)",          "maps": "https://maps.app.goo.gl/JU7F6xtCkLYxx6988"},
]

conn = psycopg2.connect(os.getenv("DATABASE_URL"))
cur = conn.cursor()
cur.execute(
    "UPDATE negocios SET lugares_reunion = %s WHERE codigo = 'SE1'",
    (Json(lugares),)
)
conn.commit()
cur.close()
conn.close()
print("✅ Lugares de SE1 actualizados con Google Maps.")
