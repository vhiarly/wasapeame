import os
import re
import threading
import time
import unicodedata
import requests as http_requests
from flask import Flask, request, g, make_response, render_template, jsonify
from dotenv import load_dotenv
from db import init_pool, execute
from negocio_router import detectar_codigo, obtener_negocio, es_numero_negocio
from flujo_pedidos import manejar_pedido, manejar_negocio, tiene_flujo_activo, limpiar_flujo, cancelar_timeout
from flujo_citas import manejar_cita, manejar_negocio_citas, tiene_flujo_citas, tiene_sesion_admin_citas, iniciar_recordatorios
from flujo_registro import manejar_registro, iniciar_registro, tiene_flujo_registro
from asistente_ia import consultar_ia, respuesta_ayuda
from oauth_routes import oauth_bp

load_dotenv()
init_pool()

execute("DELETE FROM conversaciones_pedidos WHERE timeout_en < NOW()")

app = Flask(__name__)
app.register_blueprint(oauth_bp, url_prefix='/oauth')

@app.route("/ping")
def ping():
    return "¡El servidor está vivo!", 200

@app.after_request
def log_response(response):
    numero = getattr(g, "numero_cliente", "?")
    if numero != "?":
        print(f"[OUT] {numero}: responded")
    return response

META_ACCESS_TOKEN    = os.getenv("META_ACCESS_TOKEN")
META_PHONE_NUMBER_ID = os.getenv("META_PHONE_NUMBER_ID")
META_VERIFY_TOKEN    = os.getenv("META_VERIFY_TOKEN", "wasapeame_verify_2026")

def meta_send(to, body, media_url=None):
    phone = to.replace("whatsapp:+", "").replace("+", "").strip()
    url = f"https://graph.facebook.com/v19.0/{META_PHONE_NUMBER_ID}/messages"
    headers = {
        "Authorization": f"Bearer {META_ACCESS_TOKEN}",
        "Content-Type": "application/json"
    }
    if media_url:
        payload = {
            "messaging_product": "whatsapp",
            "to": phone,
            "type": "image",
            "image": {"link": media_url, "caption": body or ""}
        }
    else:
        payload = {
            "messaging_product": "whatsapp",
            "to": phone,
            "type": "text",
            "text": {"body": body, "preview_url": False}
        }
    try:
        resp = http_requests.post(url, json=payload, headers=headers, timeout=10)
        resp.raise_for_status()
    except Exception as e:
        print(f"[META] Error enviando a {to}: {e}")

def _get_meta_media_url(media_id):
    url = f"https://graph.facebook.com/v19.0/{media_id}"
    headers = {"Authorization": f"Bearer {META_ACCESS_TOKEN}"}
    resp = http_requests.get(url, headers=headers, timeout=10)
    resp.raise_for_status()
    return resp.json()["url"]

timers           = {}
timers_relay     = {}
_clientes_vistos = set()
TIMEOUT_SEGUNDOS = 180
RELAY_SEGUNDOS   = 1800

_PATRONES_NEGOCIO = {
    "pedidos": [r"^no\s+hay\b", r"\blisto\b"],
    "citas":   [r"mis\s+citas", r"ocupado\s+hasta\b", r"\bno\s+disponible\b", r"\blibre\s+\w+", r"^cancelar\s+cita\b", r"^cancelar\s+\d{4}", r"^confirmar\s+pago\b", r"^rechazar\s+pago\b", r"^chat\s+\d+", r"^cerrar\s+chat\s+\d+", r"^comprobante\s+reembolso\s+\d+", r"^no\s+show\s+\d+", r"^(aprobar|rechazar)\s+(reagendar|reembolso)\s+\d+"],
    "comun":   [r"^ayuda$", r"^admin\s+"],
}

def _es_comando_negocio(msg_lower, modo):
    patrones = _PATRONES_NEGOCIO.get(modo, []) + _PATRONES_NEGOCIO["comun"]
    return any(re.search(p, msg_lower) for p in patrones)

def detener_timer(numero_cliente):
    if numero_cliente in timers:
        timers[numero_cliente].cancel()
        del timers[numero_cliente]

def cancelar_por_timeout(numero_cliente):
    cancelar_timeout(numero_cliente, meta_send)
    timers.pop(numero_cliente, None)
    try:
        meta_send(numero_cliente, "Tu sesión expiró por inactividad. Escribe *Hola* si quieres comunicarte con Wasapeame o el código del negocio para empezar de nuevo.")
    except Exception:
        pass

def reiniciar_timer(numero_cliente):
    if numero_cliente in timers:
        timers[numero_cliente].cancel()
    timer = threading.Timer(TIMEOUT_SEGUNDOS, cancelar_por_timeout, args=[numero_cliente])
    timer.daemon = True
    timer.start()
    timers[numero_cliente] = timer

def cerrar_relay_por_timeout(numero_cliente):
    from flujo_citas import cerrar_relay_timeout
    timers_relay.pop(numero_cliente, None)
    cerrar_relay_timeout(numero_cliente, meta_send)

def iniciar_timer_relay(numero_cliente):
    if numero_cliente in timers_relay:
        timers_relay[numero_cliente].cancel()
    t = threading.Timer(RELAY_SEGUNDOS, cerrar_relay_por_timeout, args=[numero_cliente])
    t.daemon = True
    t.start()
    timers_relay[numero_cliente] = t

def cancelar_timer_relay(numero_cliente):
    if numero_cliente in timers_relay:
        timers_relay[numero_cliente].cancel()
        timers_relay.pop(numero_cliente, None)

iniciar_recordatorios(meta_send)
LIMITE_MSG = 1500

def _msg_perdido():
    return "No entendí tu mensaje. ¿Qué necesitas?\n\n1. Hacer un pedido\n2. Agendar una cita\n3. Hablar con un negocio\n4. Registrar mi negocio\n\nEscribe el número de tu opción o el *código del negocio* directamente."

def _enviar(texto, numero):
    if len(texto) <= LIMITE_MSG:
        meta_send(numero, texto)
        return
    partes, actual = [], ""
    for linea in texto.split("\n"):
        candidato = actual + ("\n" if actual else "") + linea
        if len(candidato) > LIMITE_MSG and actual:
            partes.append(actual)
            actual = linea
        else:
            actual = candidato
    if actual:
        partes.append(actual)
    for parte in partes:
        meta_send(numero, parte)
        time.sleep(1)

@app.route("/webhook", methods=["GET", "POST"])
def webhook():
    if request.method == "GET":
        if request.args.get("hub.verify_token") == "wasapeame_verify_2026":
            return request.args.get("hub.challenge"), 200
        return "Token incorrecto", 403
    
    try:
        data = request.get_json(silent=True) or {}
        entry = data.get("entry", [{}])[0]
        changes = entry.get("changes", [{}])[0]
        value = changes.get("value", {})
        
        # Extraer info básica
        msg_obj = value.get("messages", [{}])[0]
        if not msg_obj: return "OK", 200
        
        numero_cliente = msg_obj.get("from")
        body_raw = msg_obj.get("text", {}).get("body", "")
        media_id = msg_obj.get("image", {}).get("id")
        media_url = _get_meta_media_url(media_id) if media_id else None
        
        # Procesamiento
        _raw = unicodedata.normalize("NFKC", body_raw)
        _raw = re.sub(r"[*_~`]", "", _raw)
        _raw = re.sub(r"\s+", " ", _raw).strip()
        mensaje = _raw
        mensaje_lower = mensaje.lower().strip()
        g.numero_cliente = numero_cliente
        
        # ── RELAY ──
        from flujo_citas import manejar_relay_mensaje
        relay_resp = manejar_relay_mensaje(numero_cliente, mensaje, media_url, meta_send, iniciar_timer_relay, cancelar_timer_relay)
        if relay_resp is not None:
            if relay_resp: meta_send(numero_cliente, relay_resp)
            return jsonify({"status": "ok"}), 200

        # ── MENSAJES DE NEGOCIOS DEL ROUTER ──
        codigo_emisor = es_numero_negocio(numero_cliente)
        if codigo_emisor:
            neg_emisor = obtener_negocio(codigo_emisor)
            modo_emisor = neg_emisor.get("modo") if neg_emisor else "pedidos"
            codigo_en_msg, _ = detectar_codigo(mensaje)
            es_admin_pin_citas = ((re.match(r"^admin\s+", mensaje_lower) and modo_emisor != "citas") or (modo_emisor != "citas" and tiene_sesion_admin_citas(numero_cliente)))
            if not codigo_en_msg and _es_comando_negocio(mensaje_lower, modo_emisor) and not es_admin_pin_citas:
                if mensaje_lower.strip() == "ayuda":
                    meta_send(numero_cliente, respuesta_ayuda(modo_emisor))
                    return jsonify({"status": "ok"}), 200
                resultado = manejar_negocio_citas(numero_cliente, mensaje, meta_send) if modo_emisor == "citas" else manejar_negocio(numero_cliente, codigo_emisor, mensaje, meta_send)
                if resultado is None: resultado = consultar_ia(codigo_emisor, modo_emisor, mensaje)
                if resultado: _enviar(resultado, numero_cliente)
                return jsonify({"status": "ok"}), 200

        # ── ADMIN CITAS ──
        if re.match(r"^admin\s+", mensaje_lower) or tiene_sesion_admin_citas(numero_cliente):
            if mensaje_lower.strip() == "ayuda":
                meta_send(numero_cliente, respuesta_ayuda("citas"))
                return jsonify({"status": "ok"}), 200
            resultado = manejar_negocio_citas(numero_cliente, mensaje, meta_send, iniciar_timer_relay=iniciar_timer_relay, cancelar_timer_relay=cancelar_timer_relay)
            if resultado: _enviar(resultado, numero_cliente)
            return jsonify({"status": "ok"}), 200

        # ── FLUJO REGISTRO ──
        if tiene_flujo_registro(numero_cliente):
            resultado = manejar_registro(numero_cliente, mensaje, meta_send)
            if resultado: meta_send(numero_cliente, resultado)
            return jsonify({"status": "ok"}), 200

        # ── ROUTER DE NEGOCIOS (clientes) ──
        codigo, resto = detectar_codigo(mensaje)
        if codigo or tiene_flujo_activo(numero_cliente) or tiene_flujo_citas(numero_cliente):
            msg_flujo = resto if codigo else mensaje
            modo = "citas" if tiene_flujo_citas(numero_cliente) else ("pedidos" if not codigo else (obtener_negocio(codigo).get("modo") or "pedidos"))
            if modo == "citas": respuesta = manejar_cita(numero_cliente, codigo, msg_flujo, meta_send, media_url=media_url)
            else:
                respuesta = manejar_pedido(numero_cliente, codigo, msg_flujo, meta_send, media_url=media_url)
                if tiene_flujo_activo(numero_cliente): reiniciar_timer(numero_cliente)
                else: detener_timer(numero_cliente)
            if respuesta: _enviar(respuesta, numero_cliente)
            else: meta_send(numero_cliente, _msg_perdido())
            return jsonify({"status": "ok"}), 200

        # ── SIN CÓDIGO ──
        if numero_cliente not in _clientes_vistos:
            _clientes_vistos.add(numero_cliente)
            meta_send(numero_cliente, "Bienvenido a *Wasapeame* 👋\n\nConecta con tu negocio favorito directo desde WhatsApp.\n🛒 Pedidos  |  📅 Citas  |  💬 Consultas\n\n🔑 Escribe el *código del negocio* para comenzar.\n📲 Si no lo tienes, pídelo al negocio.")
            return jsonify({"status": "ok"}), 200

        if mensaje_lower.strip() in ["1", "2", "3"]:
            opts = {"1": "Para hacer un pedido", "2": "Para agendar una cita", "3": "Escribe el código del negocio"}
            meta_send(numero_cliente, f"{opts[mensaje_lower.strip()]} escribe el *código del negocio*.\n📲 Si no lo tienes, pídelo al negocio.")
            return jsonify({"status": "ok"}), 200
        if mensaje_lower.strip() == "4":
            meta_send(numero_cliente, iniciar_registro(numero_cliente, meta_send))
            return jsonify({"status": "ok"}), 200

        meta_send(numero_cliente, _msg_perdido())
        return jsonify({"status": "ok"}), 200

    except Exception as e:
        print(f"DEBUG: ERROR AL PROCESAR: {str(e)}")
        return jsonify({"status": "error", "message": str(e)}), 200

@app.route("/")
def index(): return render_template("index.html")

@app.route("/descargo")
def descargo(): return render_template("descargo.html")

@app.route("/privacy")
@app.route("/privacy.html")
def privacy(): return render_template("privacy.html")

@app.route("/terms")
@app.route("/terms.html")
def terms(): return render_template("terms.html")

@app.route("/googlee98445ec59f6ead6.html", methods=["GET"])
def google_verification():
    return make_response("google-site-verification: googlee98445ec59f6ead6.html", 200, {"Content-Type": "text/html; charset=utf-8"})

@app.route("/privacidad", methods=["GET"])
def privacidad():
    html = """<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"/><title>Privacidad</title></head><body><h1>Política de Privacidad</h1><p>Versión 2026</p></body></html>"""
    return make_response(html, 200, {"Content-Type": "text/html; charset=utf-8"})

if __name__ == "__main__":
    app.run(debug=True, port=3000)
